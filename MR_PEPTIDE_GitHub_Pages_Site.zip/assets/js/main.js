
(function(){
  const btn = document.querySelector('.nav-toggle');
  const nav = document.querySelector('#site-nav');
  if(btn && nav){
    btn.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      btn.setAttribute('aria-expanded', String(open));
    });
  }

  // Catalog search/filter (if present)
  const q = document.querySelector('#q');
  const cat = document.querySelector('#cat');
  const rows = Array.from(document.querySelectorAll('[data-item-row]'));
  function apply(){
    const query = (q?.value || '').trim().toLowerCase();
    const c = (cat?.value || 'all');
    rows.forEach(r=>{
      const name = (r.getAttribute('data-name')||'').toLowerCase();
      const code = (r.getAttribute('data-code')||'').toLowerCase();
      const category = (r.getAttribute('data-category')||'all');
      const okQ = !query || name.includes(query) || code.includes(query);
      const okC = (c==='all') || (category===c);
      r.style.display = (okQ && okC) ? '' : 'none';
    });
  }
  q?.addEventListener('input', apply);
  cat?.addEventListener('change', apply);
})();
