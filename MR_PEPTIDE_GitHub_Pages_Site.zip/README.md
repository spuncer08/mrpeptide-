# MR. PEPTIDE (Free Website)

This is a free static site ready for **GitHub Pages**.

## Publish (GitHub Pages)
1. Create a GitHub account (free) if you don’t have one.
2. Create a new repository named: **mrpeptide** (or any name you want).
3. Upload everything in this folder to the repo (keep the same structure).
4. In the repo: **Settings → Pages**
   - Source: **Deploy from a branch**
   - Branch: **main** / **root**
5. Your site will be live at:
   `https://YOUR-USERNAME.github.io/mrpeptide/`

## Edit the Catalog
- Update `assets/data/catalog.json` (recommended) and/or edit `catalog.html`.
- If you send me your full 133-item master list, I can convert it into this site format.

## Notes
- All copy is written to be **Research Use Only** (no dosing, no medical claims).
